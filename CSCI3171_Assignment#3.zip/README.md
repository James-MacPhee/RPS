Rock Paper Scissors game created by Anirekh Jain & James MacPhee
Our game is set up so the server (EMPIRE) always wins.

Contribution per partner:
We actually both programmed our own programs and realized we both had the same error of not being able to loop through.
We then decided to work together and figured that problem out together. We then chose to submit a combined copy.
So we contributed equally.

Compile:
gcc <cfile.c> -o <cfile>

Run:
## ./server 6012
## ./client bluenose 6012

Sources:
We took syntax and knowledge of the socket functions from the below link:
http://www.linuxhowtos.org/C_C++/socket.htm
